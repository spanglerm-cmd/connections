# Gifted Connections — Version 1

This folder contains the first standalone prototype of the Connections game.

Files:
- index.html — the complete game

Current puzzle:
- Puzzle ID: 1
- Title: Connections Puzzle 1

The puzzle data is located near the bottom of index.html inside `const puzzle = { ... }`.

This prototype does not yet connect to Google Sheets. That will come after we confirm the game design.
